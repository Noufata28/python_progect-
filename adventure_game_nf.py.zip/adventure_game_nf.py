import time
import random


def print_s(msg_print):
    print(msg_print)
    time.sleep(0)


def display():
    print_s("I am Nouf, at first I will explain the game.")
    print_s("There are three boxes , you will choose one to break it.")
    print_s("The first box needs three throws, the second to one throw, "
            "and the third you need to break it two throws .")
    print_s("Note: Choose the number of throws will be random.")
    print_s("Are you ready .. !")


def choose_box(throws):
    box = input("\nPlease Choose a box number to try your luck:\n "
                "1 or 2 or 3\n")
    if box == '1':
        first_box(throws)
    elif box == '2':
        second_box(throws)
    elif box == '3':
        third_box(throws)
    else:
        choose_box(throws)


def first_box(throws):
    print_s("\nThe first box, let's see your luck how much gives you a throw.")
    print_s("You got number of throws, " + throws + ".")
    if throws == '1':
        print_s("Your luck good, you broke it and you won.")
    else:
        print_s("\nUnfortunately, you could not break it.")
    play_again(throws)


def second_box(throws):
    print_s("\nThe second, You only need one throw.\n "
            "You got number of throws, " + throws + ".")
    if throws == '2':
        print_s("I told you you need one throw, you did well.")
    else:
        print_s("\nDon't worry, try your luck again to win.")
    play_again(throws)


def third_box(throws):
    print_s("\nThe third box, You need to two throws to break it.")
    print_s("You got number of throws, " + throws + ".")
    if throws == '3':
        print_s("This is great, you broke it.")
    else:
        print_s("\nOh, you couldn't win, with this number of throws.")
    play_again(throws)


def play_again(throws):
    try_again = input("Do you want to try your luck and play again? "
                      "yes / no !\n").lower()
    if try_again == 'no':
        exit(print_s("\nGOODBYE!!."))
    elif try_again == 'yes':
        print_s("That's great, let's go..")
        play_game()
    else:
        print_s("please enter 'yes' OR 'no' !")
        play_again(throws)


def play_game():
    display()
    throws = str(random.randint(1, 3))
    choose_box(throws)
    play_again(throws)


play_game()
